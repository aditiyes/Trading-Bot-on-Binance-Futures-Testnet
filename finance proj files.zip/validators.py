"""
Input validation for trading bot parameters.

Validates symbols, sides, order types, quantities, and prices.
"""

from typing import Tuple
from decimal import Decimal, InvalidOperation


class ValidationError(ValueError):
    """Custom exception for validation errors."""
    pass


class OrderValidator:
    """Validates order parameters."""
    
    # Valid trading pairs on Binance Futures
    VALID_SYMBOLS = {
        "BTCUSDT", "ETHUSDT", "BNBUSDT", "XRPUSDT", "ADAUSDT",
        "DOGEUSDT", "MATICUSDT", "SEIUSDT", "LINKUSDT", "LTCUSDT",
        "SOLUSDT", "AVAXUSDT", "UNIUSDT", "ATOMUSDT", "XLMUSDT"
    }
    
    VALID_SIDES = {"BUY", "SELL"}
    VALID_ORDER_TYPES = {"MARKET", "LIMIT"}
    
    @staticmethod
    def validate_symbol(symbol: str) -> str:
        """
        Validate trading symbol.
        
        Args:
            symbol: Trading symbol (e.g., BTCUSDT)
            
        Returns:
            Validated symbol in uppercase
            
        Raises:
            ValidationError: If symbol is invalid
        """
        if not symbol:
            raise ValidationError("Symbol cannot be empty")
        
        symbol = symbol.upper().strip()
        
        if symbol not in OrderValidator.VALID_SYMBOLS:
            raise ValidationError(
                f"Invalid symbol: {symbol}. Supported symbols: "
                f"{', '.join(sorted(OrderValidator.VALID_SYMBOLS))}"
            )
        
        return symbol
    
    @staticmethod
    def validate_side(side: str) -> str:
        """
        Validate order side (BUY/SELL).
        
        Args:
            side: Order side
            
        Returns:
            Validated side in uppercase
            
        Raises:
            ValidationError: If side is invalid
        """
        if not side:
            raise ValidationError("Side cannot be empty")
        
        side = side.upper().strip()
        
        if side not in OrderValidator.VALID_SIDES:
            raise ValidationError(
                f"Invalid side: {side}. Must be BUY or SELL"
            )
        
        return side
    
    @staticmethod
    def validate_order_type(order_type: str) -> str:
        """
        Validate order type (MARKET/LIMIT).
        
        Args:
            order_type: Order type
            
        Returns:
            Validated order type in uppercase
            
        Raises:
            ValidationError: If order type is invalid
        """
        if not order_type:
            raise ValidationError("Order type cannot be empty")
        
        order_type = order_type.upper().strip()
        
        if order_type not in OrderValidator.VALID_ORDER_TYPES:
            raise ValidationError(
                f"Invalid order type: {order_type}. "
                f"Must be MARKET or LIMIT"
            )
        
        return order_type
    
    @staticmethod
    def validate_quantity(quantity: str, order_type: str) -> Decimal:
        """
        Validate order quantity.
        
        Args:
            quantity: Order quantity as string
            order_type: Type of order (MARKET/LIMIT)
            
        Returns:
            Validated quantity as Decimal
            
        Raises:
            ValidationError: If quantity is invalid
        """
        if not quantity:
            raise ValidationError("Quantity cannot be empty")
        
        try:
            qty = Decimal(str(quantity).strip())
        except (InvalidOperation, ValueError):
            raise ValidationError(
                f"Invalid quantity: {quantity}. Must be a positive number"
            )
        
        if qty <= 0:
            raise ValidationError(
                f"Quantity must be positive, got: {qty}"
            )
        
        # Basic sanity check (can be adjusted based on symbol)
        if qty > Decimal("1000000"):
            raise ValidationError(
                f"Quantity {qty} exceeds maximum allowed"
            )
        
        return qty
    
    @staticmethod
    def validate_price(price: str, order_type: str) -> Decimal:
        """
        Validate order price.
        
        Args:
            price: Order price as string
            order_type: Type of order (MARKET/LIMIT)
            
        Returns:
            Validated price as Decimal
            
        Raises:
            ValidationError: If price is invalid
        """
        if order_type == "MARKET":
            if price is not None and price != "":
                raise ValidationError(
                    "MARKET orders should not have a price specified"
                )
            return None
        
        if not price:
            raise ValidationError(
                "Price is required for LIMIT orders"
            )
        
        try:
            p = Decimal(str(price).strip())
        except (InvalidOperation, ValueError):
            raise ValidationError(
                f"Invalid price: {price}. Must be a positive number"
            )
        
        if p <= 0:
            raise ValidationError(
                f"Price must be positive, got: {p}"
            )
        
        if p > Decimal("1000000"):
            raise ValidationError(
                f"Price {p} exceeds maximum allowed"
            )
        
        return p
    
    @staticmethod
    def validate_all(
        symbol: str,
        side: str,
        order_type: str,
        quantity: str,
        price: str = None
    ) -> Tuple[str, str, str, Decimal, Decimal]:
        """
        Validate all order parameters together.
        
        Args:
            symbol: Trading symbol
            side: BUY or SELL
            order_type: MARKET or LIMIT
            quantity: Order quantity
            price: Order price (required for LIMIT)
            
        Returns:
            Tuple of validated parameters
            
        Raises:
            ValidationError: If any parameter is invalid
        """
        validated_symbol = OrderValidator.validate_symbol(symbol)
        validated_side = OrderValidator.validate_side(side)
        validated_order_type = OrderValidator.validate_order_type(order_type)
        validated_quantity = OrderValidator.validate_quantity(quantity, validated_order_type)
        validated_price = OrderValidator.validate_price(price, validated_order_type)
        
        return (
            validated_symbol,
            validated_side,
            validated_order_type,
            validated_quantity,
            validated_price
        )
