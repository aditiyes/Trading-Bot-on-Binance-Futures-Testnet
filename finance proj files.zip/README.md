# Binance Futures Trading Bot

A clean, production-ready Python application for placing orders on Binance Futures Testnet (USDT-M). Features proper validation, logging, error handling, and a user-friendly CLI.

## 📋 Overview

This trading bot allows you to place **Market** and **Limit** orders on the Binance Futures Testnet with:

- ✅ Full input validation
- ✅ Structured, reusable code architecture
- ✅ Comprehensive logging (file + console)
- ✅ Exception handling for all error scenarios
- ✅ Clean CLI interface
- ✅ Support for BUY/SELL sides
- ✅ Order request/response tracking

## 🚀 Quick Start

### 1. Prerequisites

- Python 3.8+
- Binance Futures Testnet account
- API Key and Secret from Binance Testnet

### 2. Setup Binance Testnet Account

1. Go to: https://testnet.binancefuture.com
2. Create an account (or use existing account)
3. Generate API credentials:
   - Click on API Management
   - Create new API key
   - Enable "Futures Trading" permission
   - **Note:** Use testnet base URL: `https://testnet.binancefuture.com`

### 3. Install Dependencies

```bash
# Clone or extract the project
cd trading_bot

# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 4. Set Environment Variables

```bash
# Linux/Mac
export BINANCE_API_KEY="your_testnet_api_key_here"
export BINANCE_API_SECRET="your_testnet_api_secret_here"

# Windows (PowerShell)
$env:BINANCE_API_KEY="your_testnet_api_key_here"
$env:BINANCE_API_SECRET="your_testnet_api_secret_here"
```

### 5. Verify Connection

```bash
python cli.py validate
```

Expected output:
```
Testing Binance API connection...

✅ Connection successful!

Fetching account information...

Account Details:
  Total Wallet Balance: 10000.00000000
  Total Cross UnPnl: 0
✅ Validation successful!
```

## 📖 Usage Examples

### Market Order (BUY)

```bash
python cli.py order \
  --symbol BTCUSDT \
  --side BUY \
  --type MARKET \
  --quantity 0.001
```

### Limit Order (SELL)

```bash
python cli.py order \
  --symbol ETHUSDT \
  --side SELL \
  --type LIMIT \
  --quantity 0.1 \
  --price 3000
```

### Interactive Mode

Simply run without options and you'll be prompted:

```bash
python cli.py order
# Trading symbol (e.g., BTCUSDT): BTCUSDT
# Order side (BUY/SELL): BUY
# Order type (MARKET/LIMIT): LIMIT
# Quantity: 0.001
# Order price (required for LIMIT orders): 50000
```

### View Supported Symbols

```bash
python cli.py info
```

### Get Help

```bash
python cli.py --help
python cli.py order --help
```

## 📁 Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py              # Package initialization
│   ├── client.py                # Binance API client wrapper
│   ├── orders.py                # Order placement logic
│   ├── validators.py            # Input validation
│   └── logging_config.py         # Logging setup
├── cli.py                        # CLI entry point
├── requirements.txt              # Python dependencies
├── README.md                     # This file
└── logs/                         # Log files (created automatically)
    └── trading_bot_YYYYMMDD.log
```

### Module Responsibilities

- **`client.py`**: Handles Binance API communication
  - Authentication and signature generation
  - HTTP request handling
  - API error handling

- **`orders.py`**: Order management and coordination
  - Validates and places orders
  - Formats results for display
  - Coordinates between validator and client

- **`validators.py`**: Input validation
  - Validates symbols, sides, order types
  - Validates quantities and prices
  - Provides clear error messages

- **`logging_config.py`**: Logging infrastructure
  - File and console handlers
  - Structured log formatting
  - Automatic log directory creation

- **`cli.py`**: User interface
  - CLI commands and options
  - Input prompts
  - Result formatting and display

## 📊 Features

### Supported Symbols

The bot supports trading on major USDT-M futures pairs:

```
BTCUSDT, ETHUSDT, BNBUSDT, XRPUSDT, ADAUSDT, DOGEUSDT, MATICUSDT,
SEIUSDT, LINKUSDT, LTCUSDT, SOLUSDT, AVAXUSDT, UNIUSDT, ATOMUSDT, XLMUSDT
```

### Order Types

1. **MARKET Orders**
   - Execute immediately at current market price
   - No price parameter needed
   - Fastest execution

2. **LIMIT Orders**
   - Execute at specified price or better
   - Requires `--price` parameter
   - More control, may not fill immediately

### Logging

All operations are logged with timestamps and details:

```
2024-05-08 10:30:45 - trading_bot - INFO - Testing connection to Binance API...
2024-05-08 10:30:46 - trading_bot - INFO - Connection test successful
2024-05-08 10:30:47 - trading_bot - INFO - Validating order parameters...
2024-05-08 10:30:47 - trading_bot - INFO - Order request: BUY 0.001 BTCUSDT (LIMIT) @ 50000
2024-05-08 10:30:47 - trading_bot - DEBUG - API Request: POST /fapi/v1/order with params: {...}
2024-05-08 10:30:48 - trading_bot - DEBUG - API Response: {'orderId': 123456, 'status': 'NEW', ...}
2024-05-08 10:30:48 - trading_bot - INFO - Order placed successfully: {...}
```

## ⚙️ Configuration

### Environment Variables

```bash
BINANCE_API_KEY       # Required: Your Binance API key
BINANCE_API_SECRET    # Required: Your Binance API secret
```

### Command-line Options

```bash
python cli.py \
  --api-key "your_key" \
  --api-secret "your_secret" \
  --log-dir "logs" \
  order [ORDER_OPTIONS]
```

## 🔒 Error Handling

The bot handles various error scenarios:

### Validation Errors
- Invalid symbol
- Invalid order side (must be BUY/SELL)
- Invalid order type (must be MARKET/LIMIT)
- Missing or invalid price for LIMIT orders
- Invalid quantity (must be positive number)

### API Errors
- Connection failures
- Authentication errors
- Invalid requests
- Rate limiting
- Network timeouts

### Example Error Response

```
==============================================================
ORDER RESULT
==============================================================

REQUEST SUMMARY:
  Symbol:     BTCUSDT
  Side:       BUY
  Type:       LIMIT
  Quantity:   0.001
  Price:      50000

❌ ORDER FAILED
Error: Invalid symbol: XYZUSDT. Supported symbols: ADAUSDT, ATOMUSDT, ...
==============================================================
```

## 📝 Log Files

Log files are automatically created in the `logs/` directory:

- **Format**: `trading_bot_YYYYMMDD.log`
- **Content**: All API calls, responses, and errors
- **Rotation**: One log file per day
- **Levels**: DEBUG (file) and INFO (console)

### Sample Log Output

```
2024-05-08 10:15:30 - trading_bot - INFO - Validating order parameters...
2024-05-08 10:15:31 - trading_bot - INFO - Order request: BUY 0.001 BTCUSDT (MARKET)
2024-05-08 10:15:31 - trading_bot - DEBUG - API Request: POST /fapi/v1/order with params: {'symbol': 'BTCUSDT', 'side': 'BUY', 'type': 'MARKET', 'quantity': '0.001', 'timestamp': 1715176531000, 'recvWindow': 5000}
2024-05-08 10:15:32 - trading_bot - DEBUG - API Response: {'orderId': 3807814689, 'symbol': 'BTCUSDT', 'status': 'FILLED', 'executedQty': '0.001', 'avgPrice': '45000', ...}
2024-05-08 10:15:32 - trading_bot - INFO - Order placed successfully. Order ID: 3807814689, Status: FILLED
```

## 🔍 Verification

### Order Placed Successfully

When an order is successfully placed, you should see:

```
==============================================================
ORDER RESULT
==============================================================

REQUEST SUMMARY:
  Symbol:     BTCUSDT
  Side:       BUY
  Type:       MARKET
  Quantity:   0.001

ORDER RESPONSE:
  Order ID:        3807814689
  Status:          FILLED
  Executed Qty:    0.001
  Avg Price:       45000

✅ ORDER PLACED SUCCESSFULLY
==============================================================
```

And in the log file (`logs/trading_bot_YYYYMMDD.log`):
- Request parameters
- Full API response
- Success confirmation

## 📌 Important Notes

1. **Testnet vs Mainnet**
   - This bot uses Binance **Testnet** only
   - No real funds are used
   - Safe for testing and learning

2. **API Credentials**
   - **Never** hardcode API keys in code
   - Always use environment variables or secure vaults
   - Regenerate keys if exposed

3. **Order Validation**
   - All inputs are validated before API call
   - Clear error messages for invalid inputs
   - No API calls are made if validation fails

4. **Network Connection**
   - Connection is tested before placing orders
   - Network errors are handled gracefully
   - Timeout is 10 seconds per request

## 🐛 Troubleshooting

### Connection Failed

```bash
# Check API credentials
echo $BINANCE_API_KEY
echo $BINANCE_API_SECRET

# Test with validate command
python cli.py validate

# Check internet connection
ping testnet.binancefuture.com
```

### Invalid Symbol Error

```bash
# View supported symbols
python cli.py info

# Use one of the listed symbols
python cli.py order --symbol BTCUSDT ...
```

### Missing Price for Limit Order

```bash
# LIMIT orders require --price parameter
python cli.py order \
  --symbol BTCUSDT \
  --side BUY \
  --type LIMIT \
  --quantity 0.001 \
  --price 50000  # <-- Required for LIMIT
```

## 📚 Code Examples

### Using as a Library

```python
from bot.client import BinanceClient
from bot.orders import OrderManager

# Initialize
client = BinanceClient(api_key="your_key", api_secret="your_secret")
manager = OrderManager(client)

# Place order
result = manager.place_order(
    symbol="BTCUSDT",
    side="BUY",
    order_type="LIMIT",
    quantity="0.001",
    price="50000"
)

# Check result
if result["success"]:
    order_id = result["order_response"]["orderId"]
    print(f"Order placed: {order_id}")
else:
    print(f"Error: {result['error']}")
```

### Custom Validation

```python
from bot.validators import OrderValidator, ValidationError

try:
    symbol = OrderValidator.validate_symbol("BTCUSDT")
    quantity = OrderValidator.validate_quantity("0.001", "MARKET")
    print(f"Valid! {quantity} {symbol}")
except ValidationError as e:
    print(f"Invalid: {e}")
```

## 🤝 Contributing

Suggestions for improvements:

### Bonus Features (Optional)
- [ ] Add Stop-Limit orders
- [ ] Add OCO (One-Cancels-Other) orders
- [ ] Add TWAP (Time-Weighted Average Price) execution
- [ ] Add Grid trading strategy
- [ ] Add order history tracking
- [ ] Add configuration file support
- [ ] Add unit tests
- [ ] Add API rate limit handling

### Code Quality
- Uses type hints throughout
- Follows PEP 8 style guide
- Modular and reusable components
- Comprehensive error messages
- Structured logging

## 📄 License

This project is provided as-is for educational and trading purposes.

## ⏱️ Estimated Completion Time

- **Setup**: 5-10 minutes
- **Testing**: 15-30 minutes
- **Total**: Less than 60 minutes ✅

## 🎯 Acceptance Criteria Met

✅ **Core Requirements**
- [x] Python 3.x application
- [x] Places MARKET and LIMIT orders
- [x] Supports BUY and SELL sides
- [x] CLI input validation for: symbol, side, order type, quantity, price
- [x] Clear output with order request and response
- [x] Structured code (separate client, orders, validators, CLI layers)
- [x] Logging to file (DEBUG level) + console (INFO level)
- [x] Exception handling (validation, API, network errors)

✅ **Deliverables**
- [x] Clean source code
- [x] README.md with setup and examples
- [x] requirements.txt for dependencies
- [x] Log files showing MARKET and LIMIT orders
- [x] Runnable instructions

## 📞 Support

For issues or questions:
1. Check the log file in `logs/` for detailed error messages
2. Review the error message displayed on console
3. Verify API credentials and connection
4. Check supported symbols with `python cli.py info`

---

**Ready to trade? Start with:**
```bash
python cli.py order
```
