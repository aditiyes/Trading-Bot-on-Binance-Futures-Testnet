"""
Command-line interface for the trading bot.

Provides user-friendly CLI for placing orders on Binance Futures Testnet.
"""

import click
import os
from pathlib import Path

from bot.client import BinanceClient, APIError
from bot.orders import OrderManager
from bot.logging_config import setup_logging, get_logger
from bot.validators import ValidationError


@click.group()
@click.option(
    "--api-key",
    envvar="BINANCE_API_KEY",
    required=False,
    help="Binance API Key (or set BINANCE_API_KEY env var)"
)
@click.option(
    "--api-secret",
    envvar="BINANCE_API_SECRET",
    required=False,
    help="Binance API Secret (or set BINANCE_API_SECRET env var)"
)
@click.option(
    "--log-dir",
    default="logs",
    help="Directory for log files (default: logs)"
)
@click.pass_context
def cli(ctx, api_key, api_secret, log_dir):
    """
    Binance Futures Trading Bot
    
    A simple Python application for placing orders on Binance Futures Testnet.
    
    Setup:
        export BINANCE_API_KEY="your_api_key"
        export BINANCE_API_SECRET="your_api_secret"
    
    Examples:
        python cli.py order --help
        python cli.py order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
        python cli.py order --symbol ETHUSDT --side SELL --type LIMIT --quantity 0.1 --price 3000
    """
    # Setup logging
    setup_logging(log_dir=log_dir)
    logger = get_logger()
    
    # Ensure context exists and initialize client
    ctx.ensure_object(dict)
    
    # Store credentials and order manager in context
    ctx.obj["api_key"] = api_key
    ctx.obj["api_secret"] = api_secret
    ctx.obj["log_dir"] = log_dir
    ctx.obj["client"] = None
    ctx.obj["order_manager"] = None


@cli.command()
@click.option(
    "--symbol",
    prompt="Trading symbol (e.g., BTCUSDT)",
    help="Symbol to trade"
)
@click.option(
    "--side",
    type=click.Choice(["BUY", "SELL"], case_sensitive=False),
    prompt="Order side (BUY/SELL)",
    help="BUY or SELL"
)
@click.option(
    "--type",
    "order_type",
    type=click.Choice(["MARKET", "LIMIT"], case_sensitive=False),
    prompt="Order type (MARKET/LIMIT)",
    help="MARKET or LIMIT"
)
@click.option(
    "--quantity",
    prompt="Quantity",
    help="Order quantity"
)
@click.option(
    "--price",
    default=None,
    help="Order price (required for LIMIT orders)"
)
@click.pass_context
def order(ctx, symbol, side, order_type, quantity, price):
    """
    Place a new order on Binance Futures Testnet.
    
    Examples:
        python cli.py order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
        python cli.py order --symbol ETHUSDT --side SELL --type LIMIT --quantity 0.1 --price 3000
    """
    logger = get_logger()
    
    try:
        # Validate credentials
        api_key = ctx.obj.get("api_key")
        api_secret = ctx.obj.get("api_secret")
        
        if not api_key or not api_secret:
            click.echo(
                click.style(
                    "❌ Error: Binance API credentials not provided.\n"
                    "Set environment variables:\n"
                    "  export BINANCE_API_KEY='your_key'\n"
                    "  export BINANCE_API_SECRET='your_secret'\n"
                    "Or pass with --api-key and --api-secret flags",
                    fg="red"
                )
            )
            logger.error("Missing API credentials")
            return
        
        # Initialize client
        client = BinanceClient(api_key, api_secret)
        
        # Test connection
        click.echo(click.style("Testing connection to Binance API...", fg="blue"))
        try:
            client.test_connection()
            click.echo(click.style("✅ Connection successful\n", fg="green"))
        except APIError as e:
            click.echo(
                click.style(f"❌ Connection failed: {e}\n", fg="red")
            )
            return
        
        # Initialize order manager
        order_manager = OrderManager(client)
        
        # Place order
        click.echo(click.style("Processing order...\n", fg="blue"))
        result = order_manager.place_order(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            price=price
        )
        
        # Display result
        formatted_result = order_manager.format_order_result(result)
        click.echo(formatted_result)
        
        # Save result to log
        if result.get("success"):
            logger.info(f"Order placed successfully")
        else:
            logger.error(f"Order placement failed: {result.get('error')}")
        
    except KeyboardInterrupt:
        click.echo(click.style("\n❌ Order cancelled by user", fg="yellow"))
        logger.info("Order cancelled by user")
    except Exception as e:
        click.echo(click.style(f"\n❌ Error: {str(e)}", fg="red"))
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)


@cli.command()
@click.pass_context
def validate(ctx):
    """
    Validate API credentials by testing connection.
    """
    logger = get_logger()
    
    try:
        api_key = ctx.obj.get("api_key")
        api_secret = ctx.obj.get("api_secret")
        
        if not api_key or not api_secret:
            click.echo(
                click.style(
                    "❌ Error: Binance API credentials not provided.\n"
                    "Set environment variables:\n"
                    "  export BINANCE_API_KEY='your_key'\n"
                    "  export BINANCE_API_SECRET='your_secret'",
                    fg="red"
                )
            )
            return
        
        click.echo(click.style("Testing Binance API connection...\n", fg="blue"))
        
        client = BinanceClient(api_key, api_secret)
        client.test_connection()
        
        click.echo(click.style("✅ Connection successful!", fg="green"))
        
        # Get account info
        click.echo(click.style("\nFetching account information...\n", fg="blue"))
        account = client.get_account_info()
        
        if account:
            click.echo("Account Details:")
            click.echo(f"  Total Wallet Balance: {account.get('totalWalletBalance')}")
            click.echo(f"  Total Cross UnPnl: {account.get('totalCrossUnPnl')}")
            click.echo(
                click.style("✅ Validation successful!", fg="green")
            )
        
    except APIError as e:
        click.echo(click.style(f"❌ Error: {e}", fg="red"))
        logger.error(f"Validation failed: {e}")
    except Exception as e:
        click.echo(click.style(f"❌ Unexpected error: {str(e)}", fg="red"))
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)


@cli.command()
@click.pass_context
def info(ctx):
    """
    Display supported symbols and order types.
    """
    from bot.validators import OrderValidator
    
    click.echo(click.style("\nSupported Symbols:", fg="cyan"))
    symbols = sorted(OrderValidator.VALID_SYMBOLS)
    for i, symbol in enumerate(symbols, 1):
        if i % 3 == 0:
            click.echo(f"  {symbol}")
        else:
            click.echo(f"  {symbol:<12}", nl=False)
    click.echo()
    
    click.echo(click.style("\nSupported Order Types:", fg="cyan"))
    click.echo("  • MARKET - Execute at current market price")
    click.echo("  • LIMIT  - Execute at specified price or better")
    
    click.echo(click.style("\nOrder Sides:", fg="cyan"))
    click.echo("  • BUY  - Open long position")
    click.echo("  • SELL - Open short position")


if __name__ == "__main__":
    cli(obj={})
