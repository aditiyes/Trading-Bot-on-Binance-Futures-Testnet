# Trading Bot - Quick Start Guide

## 5-Minute Setup

### 1. Install Dependencies
```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Set Credentials
```bash
export BINANCE_API_KEY="your_testnet_key"
export BINANCE_API_SECRET="your_testnet_secret"
```

### 3. Test Connection
```bash
python cli.py validate
```

## Place Your First Order

### Market Order (Instant)
```bash
python cli.py order \
  --symbol BTCUSDT \
  --side BUY \
  --type MARKET \
  --quantity 0.001
```

### Limit Order (Price Control)
```bash
python cli.py order \
  --symbol ETHUSDT \
  --side SELL \
  --type LIMIT \
  --quantity 0.1 \
  --price 3000
```

## Check Results

### Log Files
```bash
cat logs/trading_bot_*.log  # View all logs
tail -20 logs/trading_bot_*.log  # Last 20 lines
```

### View Supported Symbols
```bash
python cli.py info
```

## CLI Commands

| Command | Purpose |
|---------|---------|
| `order` | Place a new order |
| `validate` | Test API connection |
| `info` | Show supported symbols |
| `--help` | Show help for any command |

## Troubleshooting

**Connection Failed?**
- Verify API key and secret
- Check internet connection
- Ensure using Binance Testnet credentials

**Invalid Symbol?**
- Run `python cli.py info` to see supported symbols
- Symbol must match exactly (case-insensitive)

**Missing Price?**
- LIMIT orders require `--price` parameter
- MARKET orders don't need price

## Project Structure

```
trading_bot/
├── bot/
│   ├── client.py      # API communication
│   ├── orders.py      # Order management
│   ├── validators.py  # Input validation
│   └── logging_config.py
├── cli.py             # Command-line interface
├── README.md          # Full documentation
├── logs/              # Log files (auto-created)
└── requirements.txt   # Dependencies
```

## Next Steps

1. ✅ Verify connection: `python cli.py validate`
2. ✅ Place MARKET order: `python cli.py order --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001`
3. ✅ Place LIMIT order: `python cli.py order --symbol ETHUSDT --side SELL --type LIMIT --quantity 0.1 --price 3000`
4. ✅ Review logs: `cat logs/trading_bot_*.log`

## Documentation

- **Full Guide**: See `README.md`
- **Code Examples**: See `examples.py`
- **API Details**: See `bot/client.py`

---

**Questions?** Check the README.md or review logs in `logs/` directory.
